package com.example.demoRestWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoRestWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoRestWebApplication.class, args);
	}

}
