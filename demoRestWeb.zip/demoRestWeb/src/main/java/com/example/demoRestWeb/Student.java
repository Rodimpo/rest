package com.example.demoRestWeb;

public class Student
{
    String imie;
    String nazwisko;
}
