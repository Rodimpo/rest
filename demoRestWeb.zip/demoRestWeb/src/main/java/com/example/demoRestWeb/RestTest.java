package com.example.demoRestWeb;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;

@RestController
public class RestTest
{
    private List<String> list = new ArrayList<String>();
    //PRACA DOMOWA
    //zmień liste stringów na liste studentów
    //post dodaje do listy
    //get zwraca całą listę
    //delete kasuje całą listę


    @GetMapping("data")
    public List<String> getData()
    {
        list.add("test");
        return list;
    }
    @PostMapping("test")
    public String test(@RequestBody Student student)
    {
        System.out.println(student.imie);
        return "ok";
    }
}
