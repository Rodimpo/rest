package com.example.demoRestWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoRestWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
